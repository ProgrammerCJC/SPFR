1. you can run the source code with sample.txt directly, but if you want to get the total result you should do something with dataset
2. sevPre.h and sevPre.cpp is used to severity prediction
3. devPre.h and devPre.cpp is used to fixer recommendation